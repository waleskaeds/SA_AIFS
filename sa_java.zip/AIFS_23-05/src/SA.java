import java.util.Scanner;

public class SA {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String nomeProf, turma, disciplina, nomeAluno;
		int i = 0, notaProva, qtdAlunos, somaNotas = 0, qtdProva;
		
		//perguntas iniciais
		System.out.println("Professor, insira seu nome: ");
		nomeProf = sc.next();
		
		System.out.println("Turma: ");
		turma = sc.next();
		
		System.out.println("Disciplina: ");
		disciplina = sc.next();
		
		System.out.println("Quantidade de alunos: ");
		qtdAlunos = sc.nextInt();

		System.out.println("Quantidade de avalia��es aplicadas: ");
		qtdProva = sc.nextInt();
		
		//aluno
		for(int iA = 1; iA <= qtdAlunos; iA++) {
		System.out.println("\nNome do Aluno "+ iA + ": ");
		nomeAluno = sc.next();
		
			for (i = 1; i <= qtdProva; i++) {
			System.out.println("Nota da "+ i + "� prova: ");
			notaProva = sc.nextInt();
			notaProva += somaNotas;
			}
		}
		
		
	}

}
